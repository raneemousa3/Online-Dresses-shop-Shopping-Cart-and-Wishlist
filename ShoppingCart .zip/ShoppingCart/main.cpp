#include <iostream>
#include "ShoppingCart.h" 
#include "Product.h"
#include "WishList.h"   // Include the header, not the .cpp file

using namespace std;

int main() {
    ShoppingCart ODDMUSE;
    WishList w;
    ODDMUSE.addProduct(38,2,"mini dress",'s',"red");
    cout<<" "<<endl;
    ODDMUSE.addProduct(90,2,"mini elida dress",'s',"black");
     cout<<" "<<endl;
      ODDMUSE.removeProduct("mini dress");
        cout<<" "<<endl;
     ODDMUSE.addProduct(30,3,"maxi dress",'s',"blue");
        cout<<" "<<endl;
         
         cout<<ODDMUSE.calculateTotal()<<endl;
        
      ODDMUSE.addProduct(66,9,"mini coquette dress",'s',"red");
          cout<<" "<<endl; 
           cout<<ODDMUSE.MovetoWishlist("maxi dress")<<endl;
           ODDMUSE.MovetoWishlist("mini coquette dress");
           ODDMUSE.MovetoWishlist("mini elida dress");
           w.MovetoShoppingCart("mini coquette dress");/*
         ODDMUSE.addProduct(66,5,"mini satin dress",'s',"black");
          cout<<" i will view your cart.."<<endl;
           ODDMUSE.viewCart();
           ODDMUSE.getCartlength();
           cout<<ODDMUSE.MovetoWishlist(66,5,"mini satin dress",'s',"black")<<endl;
           
 cout<<" "<<endl;
    cout<<ODDMUSE.calculateTotal()<<endl;
        cout<<" "<<endl;
             cout<< ODDMUSE.reduceQuantity("mini dress")<<endl;
             cout<< ODDMUSE.reduceQuantity("mini dress")<<endl;
             cout<<ODDMUSE.reduceQuantity("mini satin dress")<<endl;

        cout<<" "<<endl;
    ODDMUSE.removeProduct("maxi dress");
        cout<<" "<<endl;
     ODDMUSE.viewCart();
      ODDMUSE.removeProduct("mini coquette dress");
        cout<<" "<<endl;
     ODDMUSE.viewCart();

        cout<<" "<<endl;
       cout<< ODDMUSE.removeProduct("mini dress")<<endl;
        cout<<ODDMUSE.removeProduct("mini satin dress")<<endl;
         cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;
          cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;
          cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;
          cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;


         ODDMUSE.viewCart();
         */
     
    return 0;
}
