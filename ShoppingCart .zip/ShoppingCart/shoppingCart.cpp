#include <iostream>
#include <string>

#include "Product.h"
#include "skirts.h"
#include "tops.h"
#include "dresses.h"
#include "accessories.h"
#include "ShoppingCart.h"


using namespace std;
 WishList w;
// Constructor
std::vector<ShoppingCart*> ShoppingCart::instances;

ShoppingCart::ShoppingCart() : Cart() {
    
    total = 0.0f;
     instances.push_back(this);
     
     

}
ShoppingCart* ShoppingCart::getCurrentCart(){
    ShoppingCart* lastCart = instances.back();
     return lastCart;
}


// Reduces the quantity of a product or removes it if the quantity is 1
string ShoppingCart::reduceQuantity(string Name) {
    Product* del = NULL;
    Temp = head;
    Current = head;

    if (lengthofCart == 0) {
        return "Cart Empty";
    }

    while (Current != NULL && Current->getName() != Name) {
        Temp = Current;
        Current = Current->getNext();
    }

    if (Current == NULL) {
        return "NOT FOUND";
    }

    if (Current == head && Current->getName() == Name) {
        if (Current->getQuantity() == 1) {
            head = Current->getNext();
            cout << "DELETED first PIECE in cart: " << Current->getName() << endl;
        }
    }

    if (Current->getName() == Name) {
        if (Current->getQuantity() == 1) {
            del = Current;
            lengthofCart -= 1;
            cout << "DELETED LAST PIECE: " << Current->getName() << endl;

            Temp->setNext(Current->getNext());
            delete del;
        } else {
            cout << "Before: " << Current->getQuantity() << endl;
            Current->changeQuantity(Current->getQuantity() - 1);
            cout << "After: " << Current->getQuantity() << endl;
        }
    }

    viewCart();
    return "Removed: " + Name;
}

// Adds a product to the wishlist
string ShoppingCart::MovetoWishlist(string name) {
    Product* del = NULL;
    Temp = nullptr;  // Pointer to the node before Current
    Current = head;



    if ( head == NULL) { // Check if the cart is genuinely empty
        return "Cart Empty";
    }

    // Traverse the list to find the product
    while (Current != NULL && Current->getName() != name) {
        Temp = Current; // Keep track of the previous node
        Current = Current->getNext();
    }

    if (Current == NULL) { // Product not found
        return "NOT FOUND";
    }

    // Handle removal of the product
    if (Current == head) { // If the product is at the head
        head = Current->getNext(); // Update the head to the next node
    } else if (Temp != NULL) { // If the product is in the middle or end
        Temp->setNext(Current->getNext());
    }

    // Add the product to the wishlist
    w.addToWishlist(Current);

    // Delete the product from the cart
    del = Current;
    delete del;
    lengthofCart--;

    // Print the updated cart
    viewCart();
    cout<<"------------wishlist------------------"<<endl;
    w.viewCart();
    return "Moved to wishlist: " + name;
}

// Calculates the total price of items in the cart
float ShoppingCart::calculateTotal() {
    cout << "Calculating Total Price" << endl;
    Current = head;
    total = 0.0f; // Reset total before calculation
    while (Current != NULL) {
        total += Current->getTotalPrice();
        Current = Current->getNext();
    }
    return total;
};


