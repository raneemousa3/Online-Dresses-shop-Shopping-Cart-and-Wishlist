#pragma once
#include <iostream>
#include <string>

#include "Product.h"
#include "skirts.h"
#include "tops.h"
#include "dresses.h"
#include "accessories.h"
#include "Cart.h"
#include "ShoppingCart.h"

using namespace std;

class WishList:public Cart {
private:

public:

int lengthofCart;
WishList() : Cart() {
    lengthofCart = 0;
}

void addToWishlist(Product*);
string MovetoShoppingCart(string name);
    
};

