#include <iostream>
#include <string>
#include "Cart.h"
#include <thread> // For sleep functionality
#include <chrono> // For time durations

using namespace std::chrono;
using namespace std;



Cart::Cart(){
  
    this->head=NULL;
    this->Current=NULL;
    this->Temp=NULL;
    lengthofCart=0;
    
    }
    void Cart::addProduct(float p,int Q, string name, char l, string c) {
    if (name.find("dress") != std::string::npos){
         this->head=new dresses(p,Q,name,l,c,this->head);
         cout<<"Dress Added....."<<endl;}
          else if (name.find("skirt") != std::string::npos){
         this->head=new skirts(p,Q,name,l,c,this->head);
          cout<<"Skirt Added....."<<endl;
    }
     else if (name.find("top") != std::string::npos){
         this->head=new tops(p,Q,name,l,c,this->head);
          cout<<"Top Added....."<<endl;
    }
     else if (name.find("accessories") != std::string::npos){
         this->head=new accessories(p,Q,name,l,c,this->head);
          cout<<"Accessories Added....."<<endl;
    }
    lengthofCart=lengthofCart+1;
    cout<<"added"<<head->getName()<<" : "<<head->getQuantity()<<endl;
    std::this_thread::sleep_for(milliseconds(50));
    viewCart();

    }
    void Cart::viewCart() {
    cout << "Viewing cart..." << endl;
    std::this_thread::sleep_for(milliseconds(50));
    Current=head;
    while(Current!=NULL){
        std::this_thread::sleep_for(milliseconds(50));
        Current->toString();
        Current=Current->getNext();
    }

}
int Cart::getCartlength(){
 cout<<"length of cart: "<<lengthofCart<<endl;
 return lengthofCart ;
}
string Cart::removeProduct(string Name) {
    Product* del=NULL;
    Temp=head;
    Current=head;
     if(lengthofCart==0){
        return "Cart Empty";
    }
    while (Current!=NULL and Current->getName()!=Name){
        Temp=Current;
        Current=Current->getNext();    
    }
      if(Current==NULL){
        return "NOT FOUND";
    }
   
    if(Current==head && Current->getName()==Name){
        head=Current->getNext();
    };
     
    if(Current->getName()==Name){
        del=Current;
        lengthofCart=lengthofCart-1;

        Temp->setNext(Current->getNext()); 
            
        delete del;

    }
    
    viewCart();
    return "Removed: " + Name;
};





    

