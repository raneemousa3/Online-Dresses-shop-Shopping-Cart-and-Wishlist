#pragma once
#include <iostream>
#include <string>
#include "Product.h"
using namespace std;
class accessories:public Product{
public:
accessories(float p, int q, string n, char s, string c,Product* next) : Product(p, q, n, s, c, next){}
};
