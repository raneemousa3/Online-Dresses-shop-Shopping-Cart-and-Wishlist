#pragma once
#include "WishList.h"
#include "Cart.h"
#include <vector>


class ShoppingCart : public Cart {
private:
    float total;
    int lengthofCart;
   
   


public:
   static std::vector<ShoppingCart*> instances;
    // Constructor
    ShoppingCart();
   

    static ShoppingCart* getCurrentCart();


    // ShoppingCart-specific methods
    string reduceQuantity(string Name); // Reduces quantity of a product
    string MovetoWishlist(string name); // Adds product to wishlist
    float calculateTotal(); // Calculates total cost
};
