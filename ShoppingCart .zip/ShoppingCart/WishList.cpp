#include <iostream>
#include <string>
#include "WishList.h"
#include "ShoppingCart.h"
using namespace std;

void WishList::addToWishlist(Product* Current){
    
    if (Current->getName().find("dress") != std::string::npos){
         this->head=new dresses(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
         cout<<"Dress Added to wishlist....."<<endl;}
          else if (Current->getName().find("skirt") != std::string::npos){
         this->head=new skirts(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
          cout<<"Skirt Added to wishlist....."<<endl;
    }
     else if (Current->getName().find("top") != std::string::npos){
         this->head=new tops(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
          cout<<"Top Added to wishlist....."<<endl;
    }
     else if (Current->getName().find("accessories") != std::string::npos){
           this->head=new tops(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
          cout<<"Accessories Added to wishlist....."<<endl;
    }
    lengthofCart=lengthofCart+1;
    cout<<"added "<<head->getName()<<" : "<<head->getQuantity()<<endl;

    }
    

string WishList::MovetoShoppingCart(string name) {
    Product* del = NULL;
    Temp = nullptr;  // Pointer to the node before Current
    Current = head;

    if ( head == NULL) { 
        return "Cart Empty";
    }
   
    while (Current != NULL && Current->getName() != name) {
        Temp = Current; // Keep track of the previous node
        Current = Current->getNext();
    }

    if (Current == NULL) { // Product not found
        return "NOT FOUND";
    }

    // Handle removal of the product
    if (Current == head) { // If the product is at the head
        head = Current->getNext(); // Update the head to the next node
    } else if (Temp != NULL) { // If the product is in the middle or end
        Temp->setNext(Current->getNext());
    }
    ShoppingCart* currentCart = ShoppingCart::getCurrentCart();
    // Add the product to the shoppingcart
    if (currentCart) {
        currentCart->addProduct(Current->getPrice(), Current->getQuantity(), 
                                 Current->getName(), Current->getSize(), Current->getColor());
    };

    del = Current;
    delete del;
    lengthofCart--;
    viewCart();
    cout<<"------------ShoppingCart------------------"<<endl;
    viewCart();
    cout<<endl;
      cout<<endl;
    cout<<"------------wishlist------------------"<<endl;
    viewCart();
    return "Moved to Cart: " + name;
}

 


