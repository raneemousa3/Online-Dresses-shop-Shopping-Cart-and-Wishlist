#pragma once
#include<iostream>
#include<list>
using namespace std;

class Product{
    private:
       
            float price;
            int quantity;
            string name;
            char size;
            string color;
            Product* next;
            

           
    public:
      Product(float p, int q, string n, char s, string c, Product* next=NULL);
      
    Product* getNext();
   
    void setNext(Product* nextProduct); 



    void toString();
      string getName();
     float getPrice();
     int getQuantity();
      int changeQuantity(int changedQuantity);
    
      char getSize();
      string getColor();
    float getTotalPrice();
};




