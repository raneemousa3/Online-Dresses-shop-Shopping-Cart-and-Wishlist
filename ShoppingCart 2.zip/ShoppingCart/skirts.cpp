#include "Product.h"
#include<list>
#include<iostream>
class skirts:public Product{
public:
skirts(float p, int q, string n, char s, string c):Product( p, q, n, s, c){

}
};
