#include "Product.h"

class Dresses:public Product{
public:
Dresses(float p, int q,  string n, char s,  string c):Product( p, q, n, s, c){

}
};