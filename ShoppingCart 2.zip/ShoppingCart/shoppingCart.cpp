#include <iostream>
#include <string>

#include "Product.h"


using namespace std;

class ShoppingCart {
private:
    Product* head;  
    Product* Current;
    Product* Temp;
    float total;
    int lengthofCart;

public:
ShoppingCart(){
    this->head=NULL;
    this->Current=NULL;
    this->Temp=NULL;
        lengthofCart=0;
         total=0.0f;

};
void addProduct(float p,int Q, string name, char l, string c) {
    this->head=new Product(p,Q,name,l,c,this->head);
    lengthofCart=lengthofCart+1;
    
    }
string reduceQuantity(string Name){
    Product* del=NULL;
    Temp=head;
    Current=head;
     if(lengthofCart==0){
        return "Cart Empty";
    }
    while (Current!=NULL and Current->getName()!=Name){
        Temp=Current;
        Current=Current->getNext();    
    }
      if(Current==NULL){
        return "NOT FOUND";
    }
   
    if(Current==head && Current->getName()==Name){
        if(Current->getQuantity()==1){
             head=Current->getNext();}};

    if(Current->getName()==Name){
         if(Current->getQuantity()==1){
        del=Current;
        lengthofCart=lengthofCart-1;

        Temp->setNext(Current->getNext()); 
        delete del;}
        else{
            Current->changeQuantity(((Current->getQuantity())-1));
        }

    }
    
    
    return "Removed: " + Name;
}



string removeProduct(string Name) {
    Product* del=NULL;
    Temp=head;
    Current=head;
     if(lengthofCart==0){
        return "Cart Empty";
    }
    while (Current!=NULL and Current->getName()!=Name){
        Temp=Current;
        Current=Current->getNext();    
    }
      if(Current==NULL){
        return "NOT FOUND";
    }
   
    if(Current==head && Current->getName()==Name){
        head=Current->getNext();
    };
     
    if(Current->getName()==Name){
        del=Current;
        lengthofCart=lengthofCart-1;

        Temp->setNext(Current->getNext()); 
            
        delete del;

    }
    
    
    return "Removed: " + Name;
}

void addWishlist(float p,int Q, string name, char l, string c) {
    this->head=new Product(p,Q,name,l,c,this->head);
    }
void viewCart() {
    cout << "Viewing cart..." << endl;
    Current=head;
    while(Current!=NULL){
        Current->toString();
        Current=Current->getNext();
    }

}

float calculateTotal() {

     cout << "Calculating Total Price" << endl;
    Current=head;
    while(Current!=NULL){
        total= Current->getTotalPrice()+total;
        Current=Current->getNext();
    }; // calculated value
    return total;
}

    };
