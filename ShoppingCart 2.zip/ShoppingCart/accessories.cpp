#include "Product.cpp"

class accessories:public Product{
public:
accessories(float p, int q, const string& n, char s, const string& c):Product( p, q, n, s, c){

}
};