#include <iostream>
#include "shoppingCart.cpp" 
#include "Product.h"   // Include the header, not the .cpp file

using namespace std;

int main() {
    ShoppingCart ODDMUSE;
    ODDMUSE.addProduct(38,2,"mini dress",'s',"red");
    cout<<" "<<endl;
    ODDMUSE.addProduct(30.2,3,"maxi dress",'s',"blue");
        cout<<" "<<endl;
      ODDMUSE.addProduct(66.9,9,"mini coquette dress",'s',"red");
          cout<<" "<<endl;
         ODDMUSE.addProduct(66.9,5,"mini satin dress",'s',"black");
          cout<<" "<<endl;
           
 cout<<" "<<endl;
    cout<<ODDMUSE.calculateTotal()<<endl;
        cout<<" "<<endl;
             cout<< ODDMUSE.reduceQuantity("mini dress")<<endl;
             cout<< ODDMUSE.reduceQuantity("mini dress")<<endl;
        cout<<ODDMUSE.reduceQuantity("mini satin dress")<<endl;

        cout<<" "<<endl;
    ODDMUSE.removeProduct("maxi dress");
        cout<<" "<<endl;
     ODDMUSE.viewCart();
      ODDMUSE.removeProduct("mini coquette dress");
        cout<<" "<<endl;
     ODDMUSE.viewCart();

        cout<<" "<<endl;
       cout<< ODDMUSE.removeProduct("mini dress")<<endl;
        cout<<ODDMUSE.removeProduct("mini satin dress")<<endl;

         ODDMUSE.viewCart();
         
     
    return 0;
}
