
#include<iostream>
#include"Product.h"
#include<list>
using namespace std;
   
        
Product::Product(float p, int q, string n, char s, string c, Product* next) {
    price = p;
    quantity = q;
    name = n;
    size = s;
    color = c;
    this->next = next;
}
    Product* Product::getNext() 
    { return next; }
    void Product::setNext(Product* nextProduct) { next = nextProduct; }



    void Product::toString(){  //print product description
        cout << "Product Name: " << name << " Price: $" << price <<", "<<
             " Quantity: " << quantity << ", "<<
             " Size: " << size << ", "<<
              " Color: " << color << endl;
    }
      string Product::getName(){  //print product description
       return name;
         
    }
     float Product::getPrice(){  //print product description
       return price;
         
    }
     int Product::getQuantity(){  //print product description
       return  quantity;
    }
      int Product::changeQuantity(int changedQuantity){  //print product description

        quantity = changedQuantity;
      return quantity;
    }
      char Product::getSize(){  //print product description
       return  size;
    }
      string Product::getColor(){  //print product description
       return  color;
    }
    float Product::getTotalPrice(){  //price 
        float total= quantity*price;
        return(total);
    }


