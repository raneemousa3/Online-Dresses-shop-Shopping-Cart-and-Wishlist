#pragma once
#include <iostream>
#include <string>
#include "Product.h"
#include "skirts.h"
#include "tops.h"
#include "dresses.h"
#include "accessories.h"

using namespace std;


class Cart {
    private:
static vector<Cart*> instances;
public:
   Product* head;  
    Product* Current;
    Product* Temp;
    int lengthofCart;
    
    Cart();  // Constructor

    // Method to add a product to the cart
    void addProduct(float p, int Q, string name, char l, string c);

    // Method to view the cart
    void viewCart();
    int getCartlength();


    // Method to remove a product from the cart
    string removeProduct(string Name);
    static  vector<Cart*> getcurrentInstance();
};
