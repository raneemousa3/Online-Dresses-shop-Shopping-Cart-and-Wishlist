#pragma once
#include "WishList.h"
#include "Cart.h"

#include <memory>  
using namespace std;

class ShoppingCart : public Cart {
private:
    float total;
    int lengthofCart;
  



// Use shared_ptr to store ShoppingCart instances
//static vector<ShoppingCart*> ShoppingCartinstances;

public:
   
    // Constructor
    ShoppingCart();

    

    //static ShoppingCart* getCurrentCart();


    // ShoppingCart-specific methods
    string reduceQuantity(string Name); // Reduces quantity of a product
    string MovetoWishlist(string name); // Adds product to wishlist
    float calculateTotal(); // Calculates total cost
    //static vector<ShoppingCart*> ShoppingCartinstances;
};
