#include <iostream>
#include "ShoppingCart.h" 
#include "Product.h"
#include "WishList.h"   // Include the header, not the .cpp file

using namespace std;

WishList w;
ShoppingCart ODDMUSE;

void displayCarts() {
    
      if(w.getCartlength()!=0){
        cout << "---- Wishlist ----" << endl;
       
    w.viewCart();}
   cout<<endl;
   cout<<endl;
 if(ODDMUSE.getCartlength()!=0){
    cout << "---- Shopping Cart ----" << endl;
    ODDMUSE.viewCart();
}
   cout<<endl;}
int main() {
    cout << ODDMUSE.getcurrentInstance().back() << endl;  // Make sure ODDMUSE is created first
    cout<<w.getcurrentInstance()<<endl;
 
    ODDMUSE.addProduct(38,2,"mini dress",'s',"red");
    cout<<" "<<endl;
    displayCarts();
    ODDMUSE.addProduct(90,2,"mini elida dress",'s',"black");
     cout<<" "<<endl;
      displayCarts();
      ODDMUSE.removeProduct("mini dress");
        cout<<" "<<endl;
         displayCarts();
     ODDMUSE.addProduct(30,3,"maxi skirt",'s',"blue");
        cout<<" "<<endl;
         displayCarts();
      
         
         cout<<ODDMUSE.calculateTotal()<<endl;
        
     ODDMUSE.addProduct(66,9,"mini coquette dress",'s',"red");
          cout<<" "<<endl; 
           displayCarts();
           cout<<ODDMUSE.MovetoWishlist("maxi skirt")<<endl;
            displayCarts();
           cout<<ODDMUSE.MovetoWishlist("mini coquette dress")<<endl;
                displayCarts();
           
           w.MovetoShoppingCart("mini coquette dress");
           w.MovetoShoppingCart("maxiee");
            displayCarts();
           
         w.MovetoShoppingCart("maxi skirt");
            displayCarts();
                 
                   cout<<ODDMUSE.MovetoWishlist("mini elida dress")<<endl;
                      displayCarts();
                      w.MovetoShoppingCart("mini coquette dress");
                         displayCarts();
            ODDMUSE.MovetoWishlist("mini elida dress");
            ODDMUSE.addProduct(66,5,"mini satin dress",'s',"black");
            displayCarts();
             cout<<ODDMUSE.calculateTotal()<<endl;
                      ODDMUSE.removeProduct("mini satin dress");
                       displayCarts();
                       cout<< ODDMUSE.removeProduct("mini dress")<<endl;
        cout<<ODDMUSE.removeProduct("mini satin dress")<<endl;
         cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;
          cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;
          cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;
          cout<<ODDMUSE.removeProduct("mini elida dress")<<endl;

       
    return 0;
}
