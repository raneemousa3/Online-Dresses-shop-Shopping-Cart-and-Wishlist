#include <iostream>
#include <string>
#include "WishList.h"
#include "ShoppingCart.h"
using namespace std;

vector<WishList*> WishList::instances;


WishList::WishList()
{
instances.push_back(this);
}

 WishList* WishList::getcurrentInstance() {
        if (!instances.empty()) {
            return instances.back();
        }
        cout<<"no Wishlist instance exists"<<endl;
        return nullptr; // Handle the case where the vector is empty.
    }

void WishList::addToWishlist(Product* Current){
    cout<<endl;
    
    if (Current->getName().find("dress") != std::string::npos){
         this->head=new dresses(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
         cout<<"will keep your dress safe... but not for too long"<<endl;}
          else if (Current->getName().find("skirt") != std::string::npos){
         this->head=new skirts(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
          cout<<"will keep your skirt safe... but not for too long"<<endl;
    }
     else if (Current->getName().find("top") != std::string::npos){
         this->head=new tops(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
          cout<<"will keep your top safe... but not for too long"<<endl;
    }
     else if (Current->getName().find("accessories") != std::string::npos){
           this->head=new tops(Current->getPrice(),Current->getQuantity(),Current->getName(),Current->getSize(),Current->getColor(),this->head);
          cout<<"will keep your accessories safe, not for too long"<<endl;
    }
    
    lengthofCart=lengthofCart+1;
    
   
    cout<<endl;

    }
    

string WishList::MovetoShoppingCart(string name) {
    Product* del = NULL;
    Temp = nullptr;  // Pointer to the node before Current
    Current = head;

    if ( head == NULL) { 
        return "Cart Empty";
    }
   
    while (Current != NULL && Current->getName() != name) {
        Temp = Current; // Keep track of the previous node
        Current = Current->getNext();
    }

    if (Current == NULL) {
        cout<<"Not Found"<<endl;// Product not found
        return "NOT FOUND";
    }

    // Handle removal of the product
    if (Current == head) { // If the product is at the head
        head = Current->getNext(); // Update the head to the next node
    } else if (Temp != NULL) { // If the product is in the middle or end
        Temp->setNext(Current->getNext());
    }
    
    // Add the product to the shoppingcart
    if ((ShoppingCart::getcurrentInstance()).back()) {
        ShoppingCart::getcurrentInstance().back()->addProduct(Current->getPrice(), Current->getQuantity(), 
                                 Current->getName(), Current->getSize(), Current->getColor());
    };

    del = Current;
    delete del;
    lengthofCart--;
    /*viewCart();
    cout<<"------------ShoppingCart------------------"<<endl;
    viewCart();
    cout<<endl;
      cout<<endl;
    cout<<"------------wishlist------------------"<<endl;
    viewCart();*/
    return "Moved to Cart: " + name;
}

 


